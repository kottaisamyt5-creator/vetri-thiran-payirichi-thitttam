# FitBuddy – AI Fitness Plan Generator using Gemini Models
FastAPI + Jinja2 + SQLite (SQLAlchemy) + Google Gemini.

## Run
1. pip install -r requirements.txt
2. copy .env.example to .env and add your GEMINI_API_KEY (works without a key in fallback mode)
3. uvicorn main:app --reload
4. Open http://127.0.0.1:8000

## Features
7-day workout plan (Gemini Pro) · Nutrition tips (Gemini Flash) · Feedback-based plan update · History saved in SQLite
