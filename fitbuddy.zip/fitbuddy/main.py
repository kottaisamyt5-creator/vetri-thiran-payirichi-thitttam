"""FitBuddy - AI Fitness Plan Generator (FastAPI + Jinja2 + SQLite + Gemini)."""
import json, os
from datetime import datetime

from dotenv import load_dotenv
from fastapi import FastAPI, Form, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import Column, DateTime, Integer, String, Text, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
WORKOUT_MODEL = os.getenv("WORKOUT_MODEL", "gemini-2.5-pro")  # workout generate/update
FAST_MODEL = os.getenv("FAST_MODEL", "gemini-2.5-flash")      # nutrition tips

# ---------- Database ----------
engine = create_engine("sqlite:///./fitbuddy.db", connect_args={"check_same_thread": False})
Session = sessionmaker(bind=engine)
Base = declarative_base()


class Plan(Base):
    __tablename__ = "plans"
    id = Column(Integer, primary_key=True)
    name = Column(String(80))
    age = Column(Integer)
    goal = Column(String(40))
    level = Column(String(20))
    days = Column(Integer)
    workout = Column(Text)              # JSON list of days
    nutrition = Column(Text)            # JSON list of tips
    feedback = Column(Text, default="[]")  # JSON list of feedback strings
    created = Column(DateTime, default=datetime.utcnow)


Base.metadata.create_all(engine)

# ---------- Gemini ----------
client = None
if API_KEY:
    from google import genai
    client = genai.Client(api_key=API_KEY)


def ask_json(model, prompt):
    resp = client.models.generate_content(
        model=model, contents=prompt,
        config={"response_mime_type": "application/json"},
    )
    return json.loads(resp.text)


FORMAT = ('Return ONLY JSON: a list of 7 objects {"day":"Day 1","focus":"...",'
          '"exercises":[{"name":"...","sets":3,"reps":"10-12","rest":"60s"}],"notes":"..."}. '
          'Use an empty exercises list and focus "Rest & Recovery" for rest days.')


def fallback_workout(days, goal):
    focus = ["Upper Body", "Lower Body", "Core & Cardio", "Full Body", "Push", "Pull", "Mobility"]
    moves = ["Push-ups", "Squats", "Plank", "Lunges", "Burpees", "Glute bridge", "Mountain climbers"]
    out = []
    for i in range(7):
        if i < days:
            ex = [{"name": moves[(i + j) % 7], "sets": 3, "reps": "12", "rest": "60s"} for j in range(4)]
            out.append({"day": f"Day {i+1}", "focus": focus[i], "exercises": ex,
                        "notes": f"Warm up 5 min. Goal: {goal}."})
        else:
            out.append({"day": f"Day {i+1}", "focus": "Rest & Recovery", "exercises": [],
                        "notes": "Light walk and stretching."})
    return out


def make_workout(p):
    if not client:
        return fallback_workout(p["days"], p["goal"])
    prompt = (f"Create a personalised 7-day workout plan for a {p['age']}-year-old, "
              f"goal: {p['goal']}, level: {p['level']}, {p['days']} training days/week. {FORMAT}")
    try:
        return ask_json(WORKOUT_MODEL, prompt)
    except Exception:
        return fallback_workout(p["days"], p["goal"])


def make_nutrition(p):
    default = ["Drink 2.5-3 L water daily.", "Eat protein with every meal.",
               "Sleep 7-8 hours for recovery.", "Include vegetables and whole grains."]
    if not client:
        return default
    prompt = (f"Give 6 short nutrition and recovery tips for goal '{p['goal']}', "
              f"level '{p['level']}'. Return ONLY a JSON list of strings.")
    try:
        return ask_json(FAST_MODEL, prompt)
    except Exception:
        return default


def update_workout(plan, feedback):
    if not client:
        return json.loads(plan.workout)
    prompt = (f"Current plan: {plan.workout}\nUser feedback: {feedback}\n"
              f"Update the plan accordingly. {FORMAT}")
    try:
        return ask_json(WORKOUT_MODEL, prompt)
    except Exception:
        return json.loads(plan.workout)


# ---------- Routes ----------
app = FastAPI(title="FitBuddy")
templates = Jinja2Templates(directory="templates")


@app.get("/")
def home(request: Request):
    with Session() as db:
        history = db.query(Plan).order_by(Plan.created.desc()).limit(10).all()
    return templates.TemplateResponse(request, "index.html",
                                      {"history": history, "live": bool(client)})


@app.post("/generate")
def generate(name: str = Form(...), age: int = Form(...), goal: str = Form(...),
             level: str = Form(...), days: int = Form(...)):
    p = dict(name=name, age=age, goal=goal, level=level, days=days)
    with Session() as db:
        plan = Plan(**p, workout=json.dumps(make_workout(p)),
                    nutrition=json.dumps(make_nutrition(p)))
        db.add(plan)
        db.commit()
        return RedirectResponse(f"/plan/{plan.id}", status_code=303)


@app.get("/plan/{pid}")
def view(request: Request, pid: int):
    with Session() as db:
        plan = db.get(Plan, pid)
        if not plan:
            return RedirectResponse("/", status_code=303)
        return templates.TemplateResponse(request, "plan.html", {
            "plan": plan, "workout": json.loads(plan.workout),
            "tips": json.loads(plan.nutrition), "feedback": json.loads(plan.feedback)})


@app.post("/plan/{pid}/feedback")
def feedback(pid: int, text: str = Form(...)):
    with Session() as db:
        plan = db.get(Plan, pid)
        if plan:
            plan.workout = json.dumps(update_workout(plan, text))
            fb = json.loads(plan.feedback)
            fb.append(text)
            plan.feedback = json.dumps(fb)
            db.commit()
    return RedirectResponse(f"/plan/{pid}", status_code=303)


@app.get("/health")
def health():
    return {"status": "ok", "gemini": bool(client)}
